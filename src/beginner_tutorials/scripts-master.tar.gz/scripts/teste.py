import funcoes
import serial


porta = "/dev/ttyACM0"

velocidade = 9600;
conexao = serial.Serial(porta, velocidade);

posicao = [1,2,3,4,5]

for i in range(0,5):
	posicao[i] = 0

sensor = 7
while(int(sensor) != 6):
	sensor = conexao.readline()
	AtualizaSensor(sensor, posicao)
	if(int(sensor)!= 5):
		ExibeSituacao(posicao)
	if(int(sensor) == 6):
		print("Programa desligado\n")

conexao.close()