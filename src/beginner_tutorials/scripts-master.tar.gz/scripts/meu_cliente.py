#!/usr/bin/env python

import sys
import rospy
from beginner_tutorials.srv import *

def mult_two_ints_client(x, y):
	rospy.wait_for_service('mult_two_ints')
	try:
		mult_two_ints = rospy.ServiceProxy('mult_two_ints', AddTwoInts)
		resp1 = mult_two_ints(x, y)
		return resp1.sum
	except rospy.ServiceException, e:
		print "Service call failed: %s"%e

if __name__ == "__main__":
 	x = int(raw_input("Digite o primeiro Numero.\n"))
 	y = int(raw_input("Digite o segundo Numero.\n"))
 	print "Resultdo de %s*%s"%(x, y)
 	print "%s * %s = %s"%(x, y, mult_two_ints_client(x, y))