#!/usr/bin/env python

from beginner_tutorials.srv import *
import rospy
import serial

porta = "/dev/ttyACM0"

velocidade = 9600;
conexao = serial.Serial(porta, velocidade);

op = 0;	

while(op != "2"):
	op = raw_input("'1' liga\n'0' desliga\n'2' cancela\n");
	if(op != "2"):
		conexao.write(op);
		msg = conexao.readline();
		print("\n");
		print(msg);
conexao.close();
