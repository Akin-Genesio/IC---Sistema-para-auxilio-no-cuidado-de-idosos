#!/usr/bin/env python

import sys
import rospy
from beginner_tutorials.srv import *
import serial
import funcoes
global alertas, sala, cozinha, salaE, quintal, area
alertas = 0
sala = 0
cozinha = 0
salaE = 0
quintal = 0
area = 0
porta = "/dev/ttyACM0"

velocidade = 9600;
conexao = serial.Serial(porta, velocidade);

def Registra(sensor):
	rospy.wait_for_service('Contagem')
	try:
		Contagem = rospy.ServiceProxy('Contagem', Sensor)
		resp1 = Contagem(sensor)
		return resp1.sum
	except rospy.ServiceException, e:
		print "Service call failed: %s"%e

if __name__ == "__main__":
	posicao = [0,0,0,0,0]
	sensor = 7
	while(int(sensor) != 6):
		sensor = conexao.readline()
		funcoes.AtualizaSensor(sensor, posicao)
		if(int(sensor)!= 5):
			funcoes.ExibeSituacao(posicao)
		if(int(sensor) == 6):
			print("Programa desligado\n")
		print "Total de acoes do usuario: %s\n\n"%(Registra(int(sensor)))

conexao.close()
 	