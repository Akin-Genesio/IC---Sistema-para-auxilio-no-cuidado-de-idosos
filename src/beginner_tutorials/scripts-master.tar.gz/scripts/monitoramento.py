#!/usr/bin/env python

from beginner_tutorials.srv import *
import rospy

alertas = 0
sala = 0
cozinha = 0
salaE = 0
quintal = 0
area = 0

def handle_soma(req):
	global sala, cozinha, salaE, quintal, area, alertas

	if(int(req.a) == 0):
		sala = sala+ 1
	if(int(req.a) == 1):
		cozinha = cozinha + 1
	if(int(req.a) == 2):
		salaE = salaE + 1
	if(int(req.a) == 3):
		area = area + 1
	if(int(req.a) == 4):
		quintal = quintal + 1
	if(int(req.a) == 5):
		alertas = alertas + 1
	print"Sala: %s\n"%sala
	print"Cozinha: %s\n"%cozinha
	print"Sala de Estar: %s\n"%salaE
	print"Area de Servico: %s\n"%area
	print"Quintal: %s\n"%quintal
	print"Alertas: %s\n"%alertas
	print "#############################################"
	return sala + cozinha + salaE + area + quintal

def monitoramento_server():
	rospy.init_node('monitoramento_server')
	s = rospy.Service('Contagem', Sensor, handle_soma)
	print "Pronto para analisar os resultados."
	rospy.spin()
	rospy.close()

if __name__ == "__main__":
	monitoramento_server()