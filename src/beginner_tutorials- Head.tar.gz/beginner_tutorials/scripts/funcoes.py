#!/usr/bin/env python

from beginner_tutorials.srv import *
import rospy
import serial

porta = "/dev/ttyACM0"

velocidade = 9600;
conexao = serial.Serial(porta, velocidade);
def Alerta(posicao, sensor):
	flag = 1
	while(flag == 1):
		print("Alerta Ativado! O usuario esta com problemas\nO usuario pode estar:\n")
		
		if(posicao[0] == 1):
			print("Sala\n")
		if(posicao[1] == 1):
			print("Cozinha\n")
		if(posicao[2] == 1):
			print("Sala de Estar\n")
		if(posicao[3] == 1):
			print("Area de Servico\n")
		if(posicao[4] == 1):
			print("Quintal\n")

		sensor = conexao.readline()
		if(int(sensor) == 5):
			flag = 0
			
	print("Alerta Desligado\n")

def AtualizaSensor(sensor, posicao):
	if(int(sensor) == 0 and posicao[0] == 0):
		posicao[0] = 1
	elif(int(sensor) == 0 and posicao[0] == 1):
		posicao[0] = 0

	if(int(sensor) == 1 and posicao[1] == 0):
		posicao[1] = 1
	elif(int(sensor) == 1 and posicao[1] == 1):
		posicao[1] = 0

	if(int(sensor) == 2 and posicao[2] == 0):
		posicao[2] = 1
	elif(int(sensor) == 2 and posicao[2] == 1):
		posicao[2] = 0

	if(int(sensor) == 3 and posicao[3] == 0):
		posicao[3] = 1
	elif(int(sensor) == 3 and posicao[3] == 1):
		posicao[3] = 0

	if(int(sensor) == 4 and posicao[4] == 0):
		posicao[4] = 1
	elif(int(sensor) == 4 and posicao[4] == 1):
		posicao[4] = 0

	if(int(sensor) == 5):
		Alerta(posicao, sensor)

def ExibeSituacao(posicao):
	if(posicao[0] == 1):
		print("Sensor de prensenca: Sala (Ativado)\n")
	else:
		print("Sensor de prensenca: Sala (Desativado)\n")

	if(posicao[1] == 1):
		print("Sensor de prensenca: Cozinha (Ativado)\n")
	else:
		print("Sensor de prensenca: Cozinha (Desativado)\n")

	if(posicao[2] == 1):
		print("Sensor de prensenca: Sala de Estar (Ativado)\n")
	else:
		print("Sensor de prensenca: Sala de Estar (Desativado)\n")

	if(posicao[3] == 1):
		print("Sensor de prensenca: Area de Servico (Ativado)\n")
	else:
		print("Sensor de prensenca: Area de Servico (Desativado)\n")

	if(posicao[4] == 1):
		print("Sensor de prensenca: Quintal (Ativado)\n")
	else:
		print("Sensor de prensenca: Quintal (Desativado)\n")

	print("#######################################################\n\n")