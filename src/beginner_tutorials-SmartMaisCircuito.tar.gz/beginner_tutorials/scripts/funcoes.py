#!/usr/bin/env python

from beginner_tutorials.srv import *
import rospy
import serial
import sys
import time
import argparse
from datetime import datetime
from base import MiBand2
from constants import ALERT_TYPES

porta = "/dev/ttyACM0"

velocidade = 9600;
conexao = serial.Serial(porta, velocidade);
#MUdei aqui
def Alerta(posicao, sensor):
	print("Alerta Ativado! O usuario esta com problemas\nO usuario pode estar:\n")
		
	if(posicao[0] == 1):
		print("Sala\n")
	if(posicao[1] == 1):
		print("Cozinha\n")
	if(posicao[2] == 1):
		print("Sala de Estar\n")
	if(posicao[3] == 1):
		print("Area de Servico\n")
	if(posicao[4] == 1):
		print("Quintal\n")
	
	#Apenas acrescentando um delay de 3 segundos	
	auxtime = time.time()
	while (time.time() - auxtime <= 3):
		print ('')

def RegistraBatimentos():
	rospy.wait_for_service('Bat')
	try:
		Bat = rospy.ServiceProxy('Bat', Batimentos)
		coracao = band.get_heart_rate_one_time()
		print (int(coracao))
		resp1 = Bat(int(coracao))
		return resp1.sum
	except rospy.ServiceException, e:
		print "Service call failed: %s"%e

def AtualizaSensor(sensor, posicao):
	if(int(sensor) == 0 and posicao[0] == 0):
		posicao[0] = 1
	elif(int(sensor) == 0 and posicao[0] == 1):
		posicao[0] = 0

	if(int(sensor) == 1 and posicao[1] == 0):
		posicao[1] = 1
	elif(int(sensor) == 1 and posicao[1] == 1):
		posicao[1] = 0

	if(int(sensor) == 2 and posicao[2] == 0):
		posicao[2] = 1
	elif(int(sensor) == 2 and posicao[2] == 1):
		posicao[2] = 0

	if(int(sensor) == 3 and posicao[3] == 0):
		posicao[3] = 1
	elif(int(sensor) == 3 and posicao[3] == 1):
		posicao[3] = 0

	if(int(sensor) == 4 and posicao[4] == 0):
		posicao[4] = 1
	elif(int(sensor) == 4 and posicao[4] == 1):
		posicao[4] = 0

	freq = RegistraBatimentos()
	while(int(freq) >= 80):
		Alerta(posicao, sensor)
		freq = RegistraBatimentos()
	
	print("Alerta Desligado\n")
	#if(int(sensor) == 5):
	#	Alerta(posicao, sensor)

def ExibeSituacao(posicao):
	if(posicao[0] == 1):
		print("Sensor de prensenca: Sala (Ativado)\n")
	else:
		print("Sensor de prensenca: Sala (Desativado)\n")

	if(posicao[1] == 1):
		print("Sensor de prensenca: Cozinha (Ativado)\n")
	else:
		print("Sensor de prensenca: Cozinha (Desativado)\n")

	if(posicao[2] == 1):
		print("Sensor de prensenca: Sala de Estar (Ativado)\n")
	else:
		print("Sensor de prensenca: Sala de Estar (Desativado)\n")

	if(posicao[3] == 1):
		print("Sensor de prensenca: Area de Servico (Ativado)\n")
	else:
		print("Sensor de prensenca: Area de Servico (Desativado)\n")

	if(posicao[4] == 1):
		print("Sensor de prensenca: Quintal (Ativado)\n")
	else:
		print("Sensor de prensenca: Quintal (Desativado)\n")

	print("#######################################################\n\n")
