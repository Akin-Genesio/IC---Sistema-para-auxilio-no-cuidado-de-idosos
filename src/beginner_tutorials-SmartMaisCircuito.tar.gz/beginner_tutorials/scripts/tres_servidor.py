#!/usr/bin/env python

from beginner_tutorials.srv import *
import rospy

def handle_mult_two_ints(req):
	print "Resultado [%s * %s * %s = %s]"%(req.a, req.b, req.c, (req.a * req.b * rec.c))
	return AddTwoIntsResponse(req.a * req.b * rec.c)

def mult_two_ints_server():
	rospy.init_node('mult_two_ints_server')
	s = rospy.Service('mult_two_ints', AddTwoInts, handle_mult_two_ints)
	print "Pronto para multiplicar tres numeros."
	rospy.spin()

if __name__ == "__main__":
	mult_two_ints_server()